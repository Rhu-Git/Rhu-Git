ArduinoDigitalClock
===================

Digital clock for Arduino with Nokia 5110 LCD Display

Connecting Nokia 5110 LCD display to Arduino:

<pre>
Arduino Uno       Nokia 5110 Display
3.3V -------------------- 1-VCC
PIN #7 ------------------ 3-SCE
PIN #6 ------------------ 4-RST
PIN #5 ------------------ 5-D/C
PIN #4 ------------------ 6-DNK(MOSI) (SDIN)
PIN #3 ------------------ 7-SCLK
</pre>

Video on youtube:
http://youtu.be/-60g9EO3W8o

Blog post: 
http://blog.3d-logic.com/2012/08/26/digital-clock-on-arduino-uno-with-nokia-lcd-display/

Enjoy!

Pawel Kadluczka